// src/pages/AuthPage.tsx

import React from 'react';
import SignUp from './Auth/SignUp';


const AuthPage = () => {
  return (
    <>
      <SignUp />
    </>
  );
};

export default AuthPage;
